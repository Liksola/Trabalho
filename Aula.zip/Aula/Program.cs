﻿
using Aula;

Pessoa objeto = new Pessoa();
objeto.Nome = Console.ReadLine();
objeto.Sobrenome = Console.ReadLine();
Console.WriteLine(objeto.NomeCompleto());