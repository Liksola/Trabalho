﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula
{
    public class Pessoa
    {
        public String Nome { get; set; }
        public String Sobrenome { get; set; }

        public String NomeCompleto()
        {
            return this.Nome + " " + this.Sobrenome;
        }
    }
}
